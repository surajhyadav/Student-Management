<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
 <?php include('import/config.php'); ?>

 <style type="text/css">
     .site-btn3{
    font-size: 15px;
    color: #ffffff;
    margin: 8px;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #25D366;
    border: none;
    border-radius: 2px;
   
     }
 </style>

    <!-- Contact Section Begin -->
    <section class="">
           <div style="text-align: center;">
            <h5 style="font-family: 'Poppins', sans-serif; color: #25D366;;">Check Result</h5>
        </div>
      <div class="container mt-5">
        <table width='100%' border=0 style="font-family: 'Poppins', sans-serif;">
       
        <?php
        
         $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

         $sql = "SELECT * FROM students";
         $result = mysqli_query($conn, $sql);


        while($res = mysqli_fetch_array($result)) { 


            echo "<tr>";
            echo "<td>".$res['id'].".</td>";
            echo "<td>".$res['student_name']."</td>";
            
            echo "<td>".$res['roll_number']."</td>";
            
                

            echo "<td><a class='site-btn'  href='resultdetails.php?seatno=".$res['seatno']."'>Click</a></td>";


           

            


        }
        ?>
    </table>
        

    </div>
    </section>
    <!-- Contact Section End -->

    <!-- Contact Address End -->

<?php include('import/footer.php'); ?>