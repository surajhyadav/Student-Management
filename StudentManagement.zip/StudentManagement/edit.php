<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>
    <!-- Header Section End -->

   <style type="text/css">
     .site-btn4{
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #035aa6;
    border: none;
    border-radius: 2px;
   
     }
 </style>
   
<?php
  


 if (isset($_POST['submit'])) {

         $name = $_POST['name'];
         $roll_number = $_POST['roll_number']; 
         $seat_no = $_POST['seat_no'];
         $student_course = $_POST['course'];
         $total_marks = $_POST['total_marks'];
         $student_address = $_POST['address'];

       
       $id = $_GET['id'];

    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
  

    $sql = "UPDATE students SET student_name='$name', seatno='$seat_no', roll_number='$roll_number', student_course='$student_course', total_marks='$total_marks', student_address='$student_address' WHERE id=$id";

     $query = mysqli_query($conn, $sql);

     if ($query) {

        $text = "<h5 style='font-family: Poppins, sans-serif; color: #035aa6;  margin-top: 55px; text-align:center; margin-bottom:60px;'>Customer $name Updated Successfully</h5>";

        echo $text;
        
     } else{

        echo "Something went wrong";
     }
 }

?>
  



    <!-- Contact Section End -->


        <?php
     
            $id = $_GET['id'];
           
            
                          
                         
                          
                          $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

                          $query = "SELECT * FROM students where id=".$id;

                          $result = mysqli_query($conn, $query);

                         
                        
                            

                            
                    ?>
    
             <section class="mb-5">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-6 col-md-6">
                     <?php
                            while($res = mysqli_fetch_array($result)) {  
                            ?>
                    <div class="contact__form">

                        <form action="#" method="post">
                           
                            <div class="row mb-3">
                                <div class="col-lg-6 col-6 ">
                                    <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;" >Name*</h6>
                                    
                                    <input style="font-family: 'Poppins', sans-serif;" type="" name="name" value="<?=$res['student_name']?>">
                                    
                                </div>
                               
                                <div class="col-lg-6 col-6">
                                    <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Phone No*</h6>
                                   
                                    <input style="font-family: 'Poppins', sans-serif;" type="" name="roll_number" value=<?php echo $res['roll_number']; ?>>

                                </div>
                            </div>
                             <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Course*</h6>
                                   
                                   <input style="font-family: 'Poppins', sans-serif;" type="" name="course" value="<?=$res['student_course']?>">
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Total Marks*</h6>
                                  
                                     <input style="font-family: 'Poppins', sans-serif;" type="" name="total_marks" value=<?php echo $res['total_marks']; ?>>
                                </div>
                            </div>
                             <div class="row mb-3">
                                <div class="col-lg-12 col-12">
                                    <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Seat No.*</h6>
                                    
                                    <input style="font-family: 'Poppins', sans-serif;" type="" name="seat_no"  value=<?php echo $res['seatno']; ?>>
                                </div>
                                 
                             </div>

                             <div class="row mb-1">

                                <div class="col-lg-12 col-12">
                                    <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Examation Center*</h6>
                              
                                
                                <textarea style="font-family: 'Poppins', sans-serif;" type="" name="address"><?php echo $res['student_address']; ?></textarea>
                                    
                                </div>
                                 
                             </div>
                           
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    
                                    <button type="submit" class="site-btn4" name="submit">Update</button>
                                </div>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                     <?php

                           }

                       

                            ?>
                </div>
            </div>
        </div>
    </section>






<?php include('import/footer.php'); ?>