

<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>

   <style type="text/css">
     .site-btn3{
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #25D366;
    border: none;
    border-radius: 2px;
   
     }
 </style>

    

      <?php
        
          if (isset($_GET)) {

            $id = $_GET['id'];
              
          }


         $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

         $sql = "SELECT * FROM students where id = ".$id;
         $result = mysqli_query($conn, $sql);
          
          
          ?>

    <!-- Contact Section Begin -->
    <section class="mb-5">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-6 col-md-6">
                     <?php
                            while($res = mysqli_fetch_array($result)) {
                                
                            ?>
                    <div class="contact__form">

                        <form action="#" method="post">
                           
                            <div class="row mb-3">
                                <div class="col-lg-6 col-6 ">
                                    <h6 style="color: #db2d2e;" >Name*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['student_name']."</td>"; ?></h6>
                                    
                                </div>
                               
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Roll No*</h6>
                                    <h6  style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['roll_number']."</td>"; ?></h6>
                                </div>
                            </div>
                             <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                     <h6 style="color: #db2d2e;">Course*</h6>
                                   <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['student_course']."</td>"; ?></h6>
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="color: #db2d2e;">Total Marks Exam*</h6>
                                     <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['total_marks']."</td>"; ?></h6>
                                </div>
                            </div>
                             <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Seat No.*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['seatno']."</td>"; ?></h6>
                                </div>
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Date*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['date']."</td>"; ?></h6>
                                </div>
                                 
                             </div>

                             <div class="row mb-5">

                                <div class="col-lg-12 col-12">
                                    <h6 style="color: #db2d2e;">Examation Center*</h6>
                              <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['student_address']."</td>"; ?></h6>
                                    
                                </div>
                                 
                             </div>
                           
                            <div class="row">
                                <div class="col-lg-6  col-6">
                                    <?php
                                     echo "<td><a class='site-btn3'  href='edit.php?id=".$res['id']."' >Edit</a></td>";
                                    ?>
                                    
                                </div>
                                <div class="col-lg-6  col-6">

                                    <?php
                                     echo "<td><a class='site-btn'  href='delete.php?id=".$res['id']."' onClick='return confirm('Are you sure you want to delete?')' >Delete</a></td>";
                                    ?>
                                    
                                </div>
                            </div>
                        </form>
                        
                    </div>
                     <?php

                           }

                            ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->


<?php include('import/footer.php'); ?>