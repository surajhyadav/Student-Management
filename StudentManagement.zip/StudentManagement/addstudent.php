
<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>

    <!-- Header Section End -->

  <section>
      <div style="text-align: center;" class="mb-3">
           <?php
  


 if (isset($_POST['submit'])) {

         $name = $_POST['name'];
         $roll_number = $_POST['roll_number']; 
         $course = $_POST['course'];
         $total_marks = $_POST['total_marks'];
         $seat_no = $_POST['seat_no'];
         $address = $_POST['address'];


    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
  
     $sql = "INSERT INTO students (student_name, roll_number, student_course, total_marks, seatno, student_address) VALUES ('$name', '$roll_number', '$course', '$total_marks', '$seat_no', '$address')";

     $query = mysqli_query($conn, $sql);

     if ($query) {

        $text = "<h5 style='font-family: Poppins, sans-serif; color: #db2d2e;  margin-top: 55px;'>Customer $name Added Successfully";

        echo $text;
        
     } else{

        echo "Something went wrong";
     }
 }

 // var_dump($_POST);

?>
      </div>
  </section>

    <!-- Contact Section Begin -->
    <section class="mb-5">
        <div class="container">
          
            <div class="row">
                
                <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-lg-6 col-6">
                                    <h6 style="font-family: 'Poppins', sans-serif;">Name*</h6>
                                    <input type="text" required="" name="name">
                                </div>
                               
                                <div class="col-lg-6 col-6">
                                    <h6 style="font-family: 'Poppins', sans-serif;">Roll No*</h6>
                                    <input type="number"  required="" name="roll_number">
                                </div>
                            </div>
                             <div class="row">
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Select Course*</h6>
                                    <select name="course"> 
                                    <option value = 'science'>Science</option>
                                    
                                </select>
                                
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Total Marks Exam*</h6>
                                     <input type="number"  required="" name="total_marks" value="400">
                                </div>
                            </div>
                             <div class="row">
                                <div class="col-lg-12 col-12">
                                    <h6 style="font-family: 'Poppins', sans-serif;">Examation Seat No.*</h6>
                                    <input type="text" required="" name="seat_no">
                                </div>
                                 
                             </div>

                             <h6 style="font-family: 'Poppins', sans-serif;">Examation Center</h6>
                            <textarea placeholder="Optional" name="address"></textarea>
                            <button type="submit" class="site-btn" name="submit">Add Student</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->


<?php include('import/footer.php'); ?>