
<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>
    <!-- Header Section End -->
   
     <section>
         
     </section>

    <section class="contact spad">
        <div class="container">
                
                <div style="text-align: center;">
            <h5 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">User Login</h5>
             
         </div>

            <div class="row">
             
                <div class="col-lg-6 col-md-6 mt-5">
                    <div class="contact__form">
                        <form action="login.php" method="post">
                            <div class="row">
                                <div class="col-lg-12">
                                    <input type="text" placeholder="Login ID" name="login_id">
                                </div>
                                
                            </div>
                             <div class="row">
                                <div class="col-lg-12">
                                    <input type="password" placeholder="Password" name="password">
                                </div>
                               
                            </div>
                            <button type="submit" class="site-btn" name="submit">Login Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->




    <!-- Contact Address End -->

<?php include('import/footer.php'); ?>