 <?php 
  
  session_start();
  include('import/config.php');

  if (isset($_POST['submit'])) {

    $login_id = $_POST['login_id'];
    $password = $_POST['password'];
      

      $sql = "SELECT * FROM users WHERE login_id='".$login_id."' && password='".$password."'";
      $result = mysqli_query($conn, $sql);

      $row = mysqli_fetch_array($result);

      if (is_array($row)) {

         $_SESSION['user_id'] = $row['id'];
         $_SESSION['user_name'] = $row['name'];
            
           header("location:options.php");
      }

       else{
            
            echo "Invalid Data";

       }
  }?>