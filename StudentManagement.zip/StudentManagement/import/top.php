<?php session_start(); ?>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="HVAC Template">
    <meta name="keywords" content="HVAC, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Management System</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">

<style type="text/css">
    
  
</style>

</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Offcanvas Menu Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
      
        <div class="offcanvas__logo">
            <?php if (isset($_SESSION['user_id']) && ($_SESSION['user_name'])) {
                                         
                                         
                                        $user_name = $_SESSION['user_name'];
                                        echo "<a href='options.php'><img src='img/logofair.png' ></a>";
                                         # code...
                                     }
                                     else{
                                        echo "<a href='index.php'><img src='img/logofair.png' ></a>";
                                     }
                                    ?>
        </div>
        <nav class="offcanvas__menu mobile-menu">
            <ul>
                <li class="active"><a href="./index.php"> <?php if (isset($_SESSION['user_id']) && ($_SESSION['user_name'])) {
                                         
                                         
                                        $user_name = $_SESSION['user_name'];
                                        echo "Home ('".$user_name."')";
                                         # code...
                                     }
                                     else{
                                        echo "Home";
                                     }
                                    ?> </a></li>
               
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="offcanvas__phone__num">
            <?php
                                     if (isset($_SESSION['user_id'])) {
                                         
                                         

                                        echo '<i class="fa fa-sign-out"></i> <a href="logout.php"><span style="font-family: Poppins, sans-serif;">LogOut</span></a>';
                                         # code...
                                     }
                                     
                                    ?>               
        </div>
        
    </div>
    <!-- Offcanvas Menu End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7">
                        <ul class="header__top__widget">
                             <!-- <li style="font-family: 'Poppins', sans-serif;"><i class="fa fa-clock-o"></i> Office: 09:30 am to 06:00 pm</li>
                             <li style="font-family: 'Poppins', sans-serif;"><i class="fa fa-envelope-o"></i> Info@fairmountship.in</li> -->
                        </ul>
                    </div>
                    <div class="col-lg-5">
                        <div class="header__top__right">
                            <div class="header__top__phone">
                                <div>
                                    <?php
                                     if (isset($_SESSION['user_id'])) {
                                         
                                         

                                        echo '<i class="fa fa-sign-out"></i> <a href="logout.php"><span style="font-family: Poppins, sans-serif;">LogOut</span></a>';
                                         # code...
                                     }
                                     else{
                                        echo '<i class="fa fa-user"></i>
                                            <a href="admin.php"><span style="font-family: Poppins, sans-serif;">Login as Admin</span></a>';
                                     }
                                    ?>
                                </div>
                                </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>