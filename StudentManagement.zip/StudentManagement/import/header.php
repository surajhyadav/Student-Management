<style type="text/css">
    @media only screen and (max-width: 600px) {
   .header__logo img{
    max-width: 33%;
  }
}
</style>

     <div class="container">
            <div class="row">
                <div class="col-lg-2">
                    <div class="header__logo">
                       <!--  <a href='options.php'><img src='img/logofair.png' ></a> -->
                        <?php if (isset($_SESSION['user_id']) && ($_SESSION['user_name'])) {
                                         
                                         
                                        $user_name = $_SESSION['user_name'];
                                        echo "<a href='options.php'><img src='img/logofair.png' ></a>";
                                         # code...
                                     }
                                     else{
                                        echo "<a href='index.php'><img src='img/logofair.png' ></a>";
                                     }
                                    ?>
                    </div>
                </div>
                <div class="col-lg-10">
                    <div class="header__nav">
                        <nav class="header__menu">
                            <ul class="text-design1">
                                <li class="active" style="font-family: 'Poppins', sans-serif; color: black"><?php if (isset($_SESSION['user_id']) && ($_SESSION['user_name'])) {
                                         
                                         
                                        $user_name = $_SESSION['user_name'];
                                        echo "<a href='options.php'>Hello (<span style='color: #db2d2e;'>$user_name</span>)</a>";
                                         # code...
                                     }
                                     else{
                                        echo '<a href="index.php">Home</a>';
                                     }
                                    ?> </li>
                                <li><a href="./search.php" style="font-family: 'Poppins', sans-serif;">Search</a></li>
                                
                                <li><a href="./addstudent.php" style="font-family: 'Poppins', sans-serif;">Add Student</a></li>
                                <li><a href="./studentslist.php" style="font-family: 'Poppins', sans-serif;">Students List</a></li>
                                <li><a href="./result.php" style="font-family: 'Poppins', sans-serif;">Result</a></li>
                            </ul>
                        </nav>
                        <!-- <div class="header__nav__widget">
                            
                            <a href="#" class="primary-btn">Call</a>
                        </div> -->
                    </div>
                </div>
            </div>
            <div class="canvas__open">
                <span class="fa fa-bars"></span>
            </div>
        </div>
    </header>