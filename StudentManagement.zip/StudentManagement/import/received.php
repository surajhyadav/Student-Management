<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
 <?php include('import/config.php'); ?>

 <style type="text/css">
       .site-btn3{
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #25D366;
    border: none;
    border-radius: 2px;
   
     }
 </style>

    <!-- Contact Section Begin -->
    <section class="">
           <div style="text-align: center;">
            <h5 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Payment Received</h5>
        </div>
      <div class="container mt-5">
        <table width='100%' border=0 style="font-family: 'Poppins', sans-serif;">
       
        <?php
        //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
         $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

         $sql = "SELECT * FROM received";
         $result = mysqli_query($conn, $sql);


        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['id'].".</td>";
            echo "<td>".$res['name']."</td>";
            
            echo "<td>".$res['contact_number']."</td>";
            
                

            echo '<button class="site-btn3">Paid</button>';
           

            // echo '<td><a class="btn btn-danger" href=\"delete1.php?id=$res[id]\" onClick=\"return confirm("Are you sure you want to delete?")\"  >Delete</a></td>'; 

            


        }
        ?>
    </table>
        
     
    </div>
    </section>
    <!-- Contact Section End -->

    <!-- Contact Address End -->

<?php include('import/footer.php'); ?>