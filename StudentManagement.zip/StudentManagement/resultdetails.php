

<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>

   <style type="text/css">
     .site-btn3{
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #25D366;
    border: none;
    border-radius: 2px;
   
     }



td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}



 </style>

    

      <?php
        
          if (isset($_GET)) {

            $id = $_GET['seatno'];
              # code..
          }


         $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

         $sql = "SELECT * FROM subject where seatno = '$id'";
         $sql2 = "SELECT * FROM students where seatno = '$id'";

         $result2 = mysqli_query($conn, $sql2);


         $result = mysqli_query($conn, $sql);

          ?>

    <!-- Contact Section Begin -->
    <section class="mb-5">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-6 col-md-6">
                     <?php
                            while($res = mysqli_fetch_array($result)) {  
                               
                                $checkresult = $res['status'];

                                if ($checkresult == "Pass") {
                                    
                                    echo '<div class="alert alert-success mb-4" role="alert">
                                            Congratulations!!!    You are Promoted  to Next Semister
                                        </div>';
                                } 

                                else{
                                     echo '<div class="alert alert-danger" role="alert">
                                           You are Failed In this Semister
                                           </div>';
                                }

                               

                                while($ress = mysqli_fetch_array($result2)) {
                            ?>
                    <div class="contact__form">

                        <form action="#" method="post">
                           
                            <div class="row mb-3">
                                <div class="col-lg-6 col-6 ">
                                    <h6 style="color: #db2d2e;" >Name*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo $ress['student_name']; ?></h6>
                                    
                                </div>
                               
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Roll No*</h6>
                                    <h6  style="font-family: 'Poppins', sans-serif;"><?php echo $ress['roll_number']; ?></h6>
                                </div>
                            </div>
                             <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                     <h6 style="color: #db2d2e;">Course*</h6>
                                   <h6 style="font-family: 'Poppins', sans-serif;"><?php echo $ress['student_course']; ?></h6>
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="color: #db2d2e;">Total Marks Obtained*</h6>
                                     <h6 style="font-family: 'Poppins', sans-serif;"><?php echo $res['total']; ?> / <?php echo "<td>".$ress['total_marks']."</td>"; ?></h6>
                                </div>
                            </div>

                             <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Seat No.*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo $res['seatno']; ?></h6>
                                </div>
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Date*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo $res['date']; ?></h6>
                                </div>
                                 
                             </div>

                             <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Physics</h6>
                                    
                                </div>
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Marks*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['physics']."</td>"; ?>/100</h6>
                                </div>
                                 
                             </div>

                              <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Chemistry</h6>
                                    
                                </div>
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Marks*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['chemistry']."</td>"; ?>/100</h6>
                                </div>
                                 
                             </div>

                              <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Maths</h6>
                                    
                                </div>
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Marks*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['maths']."</td>"; ?>/100</h6>
                                </div>
                                 
                             </div>

                              <div class="row mb-3">
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Biology</h6>
                                    
                                </div>
                                <div class="col-lg-6 col-6">
                                    <h6 style="color: #db2d2e;">Marks*</h6>
                                    <h6 style="font-family: 'Poppins', sans-serif;"><?php echo "<td>".$res['biology']."</td>"; ?>/100</h6>
                                </div>
                                 
                             </div>

                             <div class="row mb-3">
                                <div class="col-lg-12">
                                    
                                    <?php 
                                         
                                         $checkpercentage = $res['total'];

                                          $percentage = ($checkpercentage / 400) * 100;

                                         

                                      if ($percentage) {
                                          
                                          echo '<div class="alert alert-primary" role="alert">
                                                You Scored : '.$percentage.' % 
                                                </div>';
                                      }

                                    ?>
                                    
                                </div>
                                
                                 
                             </div>



                            
                           
                        </form>
                        
                    </div>
                     <?php

                           }

                        }

                    ?>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->


<?php include('import/footer.php'); ?>