-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2021 at 08:22 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `management`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_name` varchar(200) NOT NULL,
  `roll_number` varchar(200) NOT NULL,
  `student_course` varchar(200) NOT NULL,
  `total_marks` int(200) NOT NULL,
  `seatno` varchar(200) NOT NULL,
  `student_address` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `roll_number`, `student_course`, `total_marks`, `seatno`, `student_address`, `date`) VALUES
(1, 'Suraj Yadav', '14066', 'science', 400, 'M022417', 'DS, School High School', '2021-08-04 13:51:29'),
(3, 'Sabdeep Dhiwar', '14067', 'science', 400, 'M022418', 'our Lady of good counsel\r\n', '2021-08-04 15:06:35'),
(4, 'Roshan Patel', '14078', 'science', 400, 'M022419', 'Khalsa College\r\n', '2021-08-05 05:12:43'),
(5, 'Suraj Shukla', '14071', 'science', 400, 'M0229594', 'M D College', '2021-08-05 05:16:45');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `seatno` varchar(200) NOT NULL,
  `maths` int(200) NOT NULL,
  `chemistry` int(200) NOT NULL,
  `physics` int(200) NOT NULL,
  `biology` int(200) NOT NULL,
  `total` int(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `seatno`, `maths`, `chemistry`, `physics`, `biology`, `total`, `status`, `date`) VALUES
(5, 'M022417', 85, 80, 50, 60, 275, 'Pass', '2021-08-04 13:37:02'),
(8, 'M022418', 70, 10, 52, 26, 158, 'Fail', '2021-08-04 15:04:17'),
(9, 'M022419', 91, 82, 60, 70, 303, 'Pass', '2021-08-05 05:13:47'),
(10, 'M0229594', 70, 61, 65, 55, 251, 'Pass', '2021-08-05 05:16:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `contact_number` varchar(200) NOT NULL,
  `login_id` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `contact_number`, `login_id`, `password`) VALUES
(1, 'Suraj Yadav', '8692990357', 'introvert.suraj', 'test123'),
(2, 'Aniket', '9967139003', 'aniket', '1234'),
(4, 'Shukla', '9967139003', 'Shukla555', 'test123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
