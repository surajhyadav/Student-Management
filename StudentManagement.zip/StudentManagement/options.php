<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>
    <!-- Header Section End -->

   <style type="text/css">
     .site-btn4{
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #035aa6;
    border: none;
    border-radius: 2px;
   
     }





@media only screen and (max-width: 600px) {
 
     .client__item {
    border: 1px solid #ebebeb;
    
    height: 60px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
}




}

.client__item img{
    max-width: 26%;

}

@media only screen and (max-width: 600px) {
  .client__item img{
    max-width: 70%;

}
}


 </style>

   
<?php 
if (isset($_SESSION)) {
  # code...


  $user_name = $_SESSION['user_name'];
  
}

?>

    <section class="mb-5">
        <div class="container ">
            <div class="row">
                
                <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-lg-12 col-12">

                                     <h4 style="font-family: 'Poppins', sans-serif;">Welcome, <?=$user_name?></h4>

                                    <h6 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">You are Logged In To System*</h6>
                                   
                                </div>
                            </div>
                                
                          
                        
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
 
<div class="">
        <div class="container mb-5">
        
            <div class="row">
                <div class="col-lg-3 col-md-4 col-3">
                    <a href="marks.php" >
                        <div class="client__item" >
                          <img src="img/marks.png" alt="">
                        
                        </div>
                    </a>
                    <p style="font-family: 'Poppins', sans-serif; color:black; text-align: center;" >Enter Marks</p>
                </div>
                <div class="col-lg-3 col-md-4 col-3">
                    <a href="search.php" class="client__item">
                        <img src="img/search.svg" alt="">
                    </a>
                    <p style="font-family: 'Poppins', sans-serif; color:black; text-align: center;" >Search</p>
                </div>
                <div class="col-lg-3 col-md-4 col-3">
                    <a href="addstudent.php" class="client__item">
                        <img src="img/add-user.svg" alt="">
                    </a>
                    <p style="font-family: 'Poppins', sans-serif; color:black; text-align: center;" >Add</p>
                </div>
                <div class="col-lg-3 col-md-4 col-3">
                    <a href="customerlist.php" class="client__item">
                        <img src="img/contact-list.svg" alt="">
                    </a>
                    <p style="font-family: 'Poppins', sans-serif; color:black; text-align: center;" >List</p>
                </div>
                <div class="col-lg-3 col-md-4 col-3">
                    <a href="./result.php" class="client__item">
                        <img src="img/result.png" alt="">
                    </a>
                    <p style="font-family: 'Poppins', sans-serif; color:black; text-align: center;" >Result</p>
                </div>
                <div class="col-lg-3 col-md-4 col-3">
                    <a href="#" class="client__item">
                        <img src="img/file.svg" alt="">
                    </a>
                    <p style="font-family: 'Poppins', sans-serif; color:black; text-align: center;" >Pdf Result</p>
                </div>
            </div>
        </div>
    </div>





<?php include('import/footer.php'); ?>