<!-- <!DOCTYPE html>
<html>
  <body>
   
    <form method="post" action="searchh.php">
      <h1>SEARCH FOR USERS</h1>
      <input type="text" name="search" required/>
      <input type="submit" value="Search"/>
    </form>


   
 
  </body>
</html> -->

<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>
    <!-- Header Section End -->

   <style type="text/css">
     .site-btn4{
    font-size: 15px;
    color: #ffffff;
    font-weight: 700;
    display: inline-block;
    padding: 15px 35px 12px 38px;
    background: #035aa6;
    border: none;
    border-radius: 2px;
   
     }
 </style>
   
<section class="">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-12 col-md-12">
                    <div class="contact__form">
                        <form action="find.php" method="post">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h6 class="mb-3" style="font-family: Poppins, sans-serif;">Student Name <span style="color: red;">OR</span> Roll No*</h6>
                                    <input type="text" required="" name="search">
                                </div>
                            </div>
                                
                            <div class="row mb-3">
                               <div class="col-lg-12 col-12">
                                   <button type="submit" class="site-btn4" name="">Search</button>

                               </div> 
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
 






<?php include('import/footer.php'); ?>

