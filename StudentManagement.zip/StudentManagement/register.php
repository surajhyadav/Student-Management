
<?php include('import/top.php'); ?>

 <?php include('import/header2.php'); ?>
 
 <?php include('import/config.php'); ?>

    <!-- Header Section End -->
 <section>
     <div class="" style="text-align: center;">
        <?php
  
   if (isset($_POST['submit'])) {

     $name = $_POST['name'];
     $contact = $_POST['contact'];
     $login_id = $_POST['login_id'];
     $password = $_POST['password'];


     $sql = "INSERT INTO users (name, contact_number, login_id, password) VALUES ('$name', '$contact', '$login_id', '$password')";
     
     $result = mysqli_query($conn, $sql);

     if ($result) {
       
        $text = "<h5 style='font-family: Poppins, sans-serif; color: #db2d2e;  margin-top: 55px;'>Account for $name Created</h5>";

        echo $text;
         
     }

     else{
         
         $text2 = "Try after Sometime";

        echo $text2;
     }



       # code...
   }



?>
         
     </div>
 </section>


    <!-- Contact Section Begin -->
    <section class="">
        <div class="container">

                <div style="text-align: center;">
            <h5 style="font-family: 'Poppins', sans-serif; color: #db2d2e;">Add Member</h5>
            <div class="row">
             
                <div class="col-lg-6 col-md-6 mt-5">
                    <div class="contact__form">
                        <form action="#" method="post">
                            <div class="row">
                                <div class="col-lg-6 col-6">
                                    <input type="text" placeholder="Name" name="name">
                                </div>
                                <div class="col-lg-6 col-6">
                                    <input type="text" placeholder="Phone No." name="contact">
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" placeholder="Login ID" name="login_id">
                                </div>
                                
                            </div>
                             <div class="row">
                                <div class="col-lg-12">
                                    <input type="password" placeholder="Password" name="password">
                                </div>
                               
                            </div>
                            <button type="submit" class="site-btn" name="submit">Register Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->


    <!-- Contact Address End -->

<?php include('import/footer.php'); ?>