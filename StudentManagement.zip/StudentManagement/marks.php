
<?php include('import/top.php'); ?>

 <?php include('import/header.php'); ?>
  <?php include('import/config.php'); ?>

    <!-- Header Section End -->

  <section>
      <div style="text-align: center;" class="mb-3">
           <?php
  


 if (isset($_POST['submit'])) {

         $seat_no = $_POST['seat_no'];
         $physics = $_POST['physics']; 
         $biology = $_POST['biology'];
         $chemistry = $_POST['chemistry'];
         $maths = $_POST['maths'];

         $total = $physics + $chemistry + $biology + $maths;

         $status = ($total/400) * 100;

         if ($status >= "50%") {
            
            $status = "Pass";
         } else{
            $status = "Fail";
         }

    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
  
     $sql = "INSERT INTO subject (seatno, physics, chemistry, biology, maths, total, status) VALUES ('$seat_no', '$physics', '$chemistry', '$biology', '$maths', '$total', '$status')";

     $query = mysqli_query($conn, $sql);

     if ($query) {

        $text = "<h5 style='font-family: Poppins, sans-serif; color: #db2d2e;  margin-top: 55px;'>Student $seat_no Marks Entered Successfully";

        echo $text;
        
     } else{

        echo "Something went wrong";
     }
 }

 

?>
      </div>
  </section>

    <!-- Contact Section Begin -->
    <section class="mb-5">
        <div class="container">
          
            <div class="row">
                
                <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="#" method="post">
                           
                             
                             <div class="row">
                                <div class="col-lg-12 col-12">
                                    <h6 style="font-family: 'Poppins', sans-serif;">Examation Seat No.*</h6>
                                    <input type="text" required="" name="seat_no">
                                </div>     
                             </div>

                             <div class="row">
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Subject*</h6>
                                    <select name="course"> 
                                          <option >Physics</option>
                                    </select>                               
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Obtained Marks Outoff 100*</h6>
                                     <input type="number"  required="" name="physics">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Subject*</h6>
                                    <select name="course"> 
                                          <option >Biology</option>
                                    </select>                               
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Obtained Marks Outoff 100*</h6>
                                     <input type="number"  required="" name="biology">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Subject*</h6>
                                    <select name="course"> 
                                          <option >Chemistry</option>
                                    </select>                               
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Obtained Marks Outoff 100*</h6>
                                     <input type="number"  required="" name="chemistry">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Subject*</h6>
                                    <select name="course"> 
                                          <option value = 'science'>Maths</option>
                                    </select>                               
                                </div>
                                 
                                <div class="col-lg-6 col-6">
                                     <h6 style="font-family: 'Poppins', sans-serif;">Obtained Marks Outoff 100*</h6>
                                     <input type="number"  required="" name="maths">
                                </div>
                            </div>


                            <button type="submit" class="site-btn" name="submit">Enter Marks</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->


<?php include('import/footer.php'); ?>